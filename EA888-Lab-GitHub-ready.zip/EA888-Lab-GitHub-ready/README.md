# EA888 Lab v1.2.0 — Race Weekend + Telemetry

Offline Android prototype/game for building, measuring, tuning and drag-racing a virtual EA888 Gen 1 / CAWB installation.

## v1.2 highlights

- **Heads-up Race Weekend** with a separately simulated rival.
- Four rival levels: Club, Street, Pro and Outlaw.
- The rival has its own reaction time, mass, dyno curve, tire/prep model and finish time.
- Live opponent car, live distance gap, win/loss result and workshop-credit reward.
- Solo mode remains available for setup testing.
- Post-run telemetry canvas: speed, RPM, boost, wheelspin and lane position over 402.336 m.
- Analysis cards for 60-foot performance, line control, limiter time, clutch temperature, gearbox temperature and driveline stress.
- Adjustable steering sensitivity and center assist.
- Real-time clutch heat, gearbox heat, limiter exposure and driveline stress are persisted in the timeslip.
- Existing PCM multisample audio lifecycle tests retained: clean restart on race 2/3 and hard stop after finish.
- Stable Android application identity and signing certificate introduced for future in-place updates.

## Main game systems retained

- 19 part clusters and 18 turbo choices up to 127 mm.
- Randy JE83 / Cat Cams / Ferrea / Nostrum / Syvecs / Cometic / ARP / K04 hybrid / HX52 / O2Q / Quaife references.
- Assembly clearances and six bench tests.
- Hidden power after a hardware/tune change until a new dyno pull is completed.
- Dyno curve, air, fuel, thermal and risk channels.
- Burnout, staging, drag tree, rear-chase quarter mile, lane steering and manual shifting.
- Only the DQ250 DSG shifts automatically; manual gearboxes still require manual shifts.
- Oil, service, wear, damage, rebuild, build slots, achievements and build-code export/import.

## Run the simulation tests

```bash
node tests/test_sim.js
```

## Run the mobile/WebView workflow test

```bash
python3 tools/browser_smoke.py \
  --assets src/assets \
  --screenshots /tmp/ea888-v120-shots \
  --report /tmp/ea888-v120-browser-report.json
```

The test uses the production HTML/CSS/JS/assets in system Chromium with a 480×1000 touch viewport. For release verification, run it against assets extracted from the final APK.

## Build the APK

```bash
python3 tools/build_apk.py \
  --output /mnt/data/EA888-Lab-v1.2.0-Race-Weekend.apk
```

No Android SDK is required. The build pipeline:

1. generates the Scirocco launcher icon;
2. patches the binary Android manifest;
3. patches the small resource table;
4. generates the WebView DEX shell;
5. packages the offline production assets;
6. signs with the stable EA888 Lab signing key;
7. verifies ZIP integrity, DEX magic, package/label/icon resources, 4-byte alignment and the JAR/v1 signature.

## Android identity

- App label: `EA888 LAB`
- Package: `nl.randy.ea888lab.stabl`
- Version name: `1.2.0-debug`
- Version code: `120`
- Launcher icon: `mipmap/app_icon`

This is the first build using the stable package/signing identity. It installs next to v1.1 because v1.1 used a different package. Future builds that keep this package and certificate can update v1.2 in place.

The private signing key is deliberately stored outside the source tree and is not included in source or release archives.

## Accuracy boundary

The app is an engineering-inspired game model, not certified engine, ECU or vehicle-dynamics software. Real hardware limits and tuning decisions must still be validated with proper measurements, logs and professional inspection.

## GitHub / Claude Code workflow

The repository includes `CLAUDE.md` with the current development handoff and priorities.

Keep the Android signing key **outside** this repository. Before building a signed APK, set:

```bash
export EA888_KEYSTORE=/absolute/path/outside/repo/ea888-lab-stable.jks
export EA888_KEY_ALIAS=ea888labstable
export EA888_KEY_PASSWORD='your-secret-password'
```

Never commit the keystore or real password. `.gitignore` excludes common signing-key and environment-file formats.
